# Google-Contact-Sync-for-Firefox-OS
Sincronizador de contatos do google para Firefox OS
